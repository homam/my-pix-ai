# @aionized/platform-client

> **Product tag:** N/A — not a shipped product. Shared library consumed by the 4 aionized
> products that use the shared "aionized platform" Supabase project (product-image-tools/Pixby,
> product-pdf-tools, my-pix-ai, ai-all-in-one-chat/Hearth). See
> [product-image-tools/docs/PLATFORM.md](../product-image-tools/docs/PLATFORM.md) for the full
> schema contract this wraps.

## What this is

Thin, typed wrappers around the shared platform's `core.*` credit/wallet RPCs
(`ensure_wallet` / `spend_credits` / `grant_credits` / `settle_payment`) plus a browser
anonymous-session-bootstrap helper. Extracted 2026-07-04 after a schema change (the
`p_product` → `p_brand` rename in migration `0005_credits_per_brand.sql`) broke
`product-pdf-tools` silently — it had hand-copied the RPC call with the old param name.
Centralizing the calls here means a schema change now breaks the build for every consumer
instead of drifting per-app.

- `src/server.ts` — `createPlatformAdmin(admin, brand)` → `ensureWallet` / `spendCredits` /
  `grantCredits` / `settlePayment`. Must be called with a **service-role** client (the RPCs are
  `SECURITY DEFINER` and require an explicit `p_user`).
- `src/client.ts` / `src/react.tsx` — `ensureAnonymousSession(supabase)` and a `<SessionBoot>`
  component for the browser-side anonymous sign-in bootstrap.
- `src/config.ts` — reads the standard `NEXT_PUBLIC_SUPABASE_URL` / `NEXT_PUBLIC_PRODUCT_KEY` /
  `NEXT_PUBLIC_BRAND_KEY` env var conventions.

**Deliberately structural typing, not the nominal `SupabaseClient` class type.** Each consuming
product is a separate repo with its own `node_modules` (no shared workspace), so two
independently installed copies of `@supabase/supabase-js` are nominally different types to
TypeScript even at the same version — private/protected class fields defeat structural typing
across separate installs. `RpcCapableClient` / `AuthCapableClient` are minimal duck-typed
interfaces instead, so any consumer's own client satisfies them regardless of which
`@supabase/*` install produced it.

## Consuming this package

Not published to a registry yet — each product depends on it via a local path:

```json
"@aionized/platform-client": "file:../platform-client"
```

(or `file:../../../platform-client` from a nested `apps/*` package in a monorepo, e.g.
`ai-all-in-one-chat/apps/web`). Run `npm run build` here after any change — consumers pick up
`dist/`, not `src/`.

## Build

```bash
npm install
npm run build       # tsc -> dist/
npm run typecheck
```
