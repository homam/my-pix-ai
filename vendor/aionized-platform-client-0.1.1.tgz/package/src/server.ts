import { InsufficientCreditsError, UnknownBrandError } from './errors.js';

export { InsufficientCreditsError, UnknownBrandError } from './errors.js';

/**
 * The minimal shape this package needs from a Supabase client. Deliberately NOT the nominal
 * `SupabaseClient` class type from `@supabase/supabase-js` — each of the 4 aionized products
 * is a separate repo with its own `node_modules` (no shared workspace), so two independently
 * installed copies of `@supabase/supabase-js` are nominally different types to TypeScript even
 * at the same version (private/protected class fields defeat structural typing). Accepting a
 * structural interface here means `createPlatformAdmin(supabaseAdmin(), brand)` type-checks
 * regardless of which supabase-js copy — or schema-scoped client type — the caller has.
 */
export interface RpcCapableClient {
  schema(name: string): {
    rpc(
      fn: string,
      args: Record<string, unknown>,
    ): PromiseLike<{ data: unknown; error: { message: string } | null }>;
  };
}

/**
 * Thin, typed wrappers around the shared platform's `core.*` RPCs (see
 * docs/PLATFORM.md in product-image-tools for the full contract). All of these
 * MUST be called with a service-role Supabase client — the RPCs are
 * `SECURITY DEFINER` and require an explicit `p_user` because `auth.uid()` is
 * null under the service role.
 *
 * Centralizing these calls here is the whole point: when the schema changes
 * (e.g. the `p_product` → `p_brand` rename in migration 0005), every consumer
 * gets a type/behavior change from one dependency bump instead of silently
 * drifting per-app (this is exactly how product-pdf-tools' credits route broke
 * on 2026-07-04 — it had hand-copied the old param name).
 */
export function createPlatformAdmin(admin: RpcCapableClient, brand: string) {
  const core = () => admin.schema('core');

  return {
    /** Lazily creates the (user, brand) wallet with the product's starter credits if missing.
     * Returns the current balance. Call before showing or spending. */
    async ensureWallet(userId: string): Promise<number> {
      const { data, error } = await core().rpc('ensure_wallet', { p_user: userId, p_brand: brand });
      if (error) {
        if (/UNKNOWN_BRAND/.test(error.message)) throw new UnknownBrandError(brand);
        throw error;
      }
      return data as number;
    },

    /** Atomic decrement. Throws InsufficientCreditsError when the balance can't cover `cost`.
     * Returns the new balance on success. */
    async spendCredits(userId: string, cost: number, reason: string, ref?: string): Promise<number> {
      const { data, error } = await core().rpc('spend_credits', {
        p_user: userId,
        p_brand: brand,
        p_cost: cost,
        p_reason: reason,
        p_ref: ref ?? null,
      });
      if (error) {
        if (/INSUFFICIENT_CREDITS/.test(error.message)) throw new InsufficientCreditsError(brand);
        if (/UNKNOWN_BRAND/.test(error.message)) throw new UnknownBrandError(brand);
        throw error;
      }
      return data as number;
    },

    /** Top-up from any source (purchase / promo / admin / comp). Returns the new balance. */
    async grantCredits(userId: string, amount: number, reason: string, ref?: string): Promise<number> {
      const { data, error } = await core().rpc('grant_credits', {
        p_user: userId,
        p_brand: brand,
        p_amount: amount,
        p_reason: reason,
        p_ref: ref ?? null,
      });
      if (error) {
        if (/UNKNOWN_BRAND/.test(error.message)) throw new UnknownBrandError(brand);
        throw error;
      }
      return data as number;
    },

    /** Idempotent payment→credit bridge. Every payment provider adapter (Stripe, DCB, card, …)
     * calls this after verifying its own event; retries on the same (provider, providerRef)
     * settle exactly once. Returns the new balance. */
    async settlePayment(
      userId: string,
      opts: {
        provider: string;
        providerRef: string;
        pack: string;
        amountCents: number;
        currency?: string;
      },
    ): Promise<number> {
      const { data, error } = await core().rpc('settle_payment', {
        p_user: userId,
        p_brand: brand,
        p_provider: opts.provider,
        p_provider_ref: opts.providerRef,
        p_pack: opts.pack,
        p_amount_cents: opts.amountCents,
        p_currency: opts.currency ?? 'usd',
      });
      if (error) {
        if (/UNKNOWN_BRAND/.test(error.message)) throw new UnknownBrandError(brand);
        throw error;
      }
      return data as number;
    },
  };
}

export type PlatformAdmin = ReturnType<typeof createPlatformAdmin>;
