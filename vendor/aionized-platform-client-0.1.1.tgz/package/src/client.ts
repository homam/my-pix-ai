import { createBrowserClient } from '@supabase/ssr';

/** Browser client for AUTH ONLY (session + anonymous sign-in). Per docs/PLATFORM.md §3,
 * it must never read/write core.* or <product>.* tables directly — go through your own
 * server routes for that. */
export function createPlatformBrowserClient(supabaseUrl: string, supabaseAnonKey: string) {
  return createBrowserClient(supabaseUrl, supabaseAnonKey);
}

/** The minimal auth surface `ensureAnonymousSession` needs. Deliberately structural, not the
 * nominal `SupabaseClient`/`createBrowserClient` return type — see the identical comment on
 * `RpcCapableClient` in server.ts for why (4 separate repos, no shared workspace, separate
 * `@supabase/*` installs). Any client — this package's own or a consumer's own — satisfies
 * this shape. */
export interface AuthCapableClient {
  auth: {
    getSession(): PromiseLike<{ data: { session: unknown } }>;
    signInAnonymously(): PromiseLike<unknown>;
  };
}

/** Ensures an anonymous (or existing) session exists. Swallows failures (anonymous
 * sign-in disabled at the project level, or offline) so callers can treat the platform
 * layer as best-effort — the product's core features shouldn't depend on this succeeding. */
export async function ensureAnonymousSession(supabase: AuthCapableClient): Promise<void> {
  try {
    const { data } = await supabase.auth.getSession();
    if (data.session) return;
    await supabase.auth.signInAnonymously();
  } catch {
    // non-fatal — the app must stay usable without a platform session
  }
}
