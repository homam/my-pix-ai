/**
 * Env var conventions every aionized product sets. See docs/PLATFORM.md (in
 * product-image-tools) §4 "Client/usage patterns" for the full contract.
 */
export interface PlatformEnv {
  supabaseUrl: string;
  supabaseAnonKey: string;
  /** Server-only. Never expose to the client. */
  supabaseServiceRoleKey?: string;
  /** This app's key in core.products. */
  productKey: string;
  /** This deployment's key in core.brands. Defaults to productKey. */
  brandKey: string;
}

/**
 * Reads the standard NEXT_PUBLIC_SUPABASE_URL / NEXT_PUBLIC_SUPABASE_ANON_KEY /
 * SUPABASE_SERVICE_ROLE_KEY / NEXT_PUBLIC_PRODUCT_KEY / NEXT_PUBLIC_BRAND_KEY env vars.
 * Throws if a required value is missing so misconfiguration fails loudly at boot,
 * not with a confusing runtime RPC error later.
 */
export function readPlatformEnv(env: Record<string, string | undefined> = process.env): PlatformEnv {
  const supabaseUrl = env.NEXT_PUBLIC_SUPABASE_URL;
  const supabaseAnonKey = env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  const productKey = env.NEXT_PUBLIC_PRODUCT_KEY;
  if (!supabaseUrl || !supabaseAnonKey) {
    throw new Error(
      'readPlatformEnv: NEXT_PUBLIC_SUPABASE_URL / NEXT_PUBLIC_SUPABASE_ANON_KEY are required. ' +
        'Use isPlatformConfigured() first if the platform layer is meant to be optional.',
    );
  }
  if (!productKey) {
    throw new Error('readPlatformEnv: NEXT_PUBLIC_PRODUCT_KEY is required (your key in core.products).');
  }
  return {
    supabaseUrl,
    supabaseAnonKey,
    supabaseServiceRoleKey: env.SUPABASE_SERVICE_ROLE_KEY,
    productKey,
    brandKey: env.NEXT_PUBLIC_BRAND_KEY || productKey,
  };
}

/** True when the platform env is present. Products where the platform layer is optional
 * (e.g. a free tool suite with no account system yet) should gate on this before using
 * anything else in this package, and degrade gracefully when it's false. */
export function isPlatformConfigured(env: Record<string, string | undefined> = process.env): boolean {
  return Boolean(env.NEXT_PUBLIC_SUPABASE_URL && env.NEXT_PUBLIC_SUPABASE_ANON_KEY && env.NEXT_PUBLIC_PRODUCT_KEY);
}
