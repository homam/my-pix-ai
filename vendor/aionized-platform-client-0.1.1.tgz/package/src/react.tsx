'use client';

import { useEffect } from 'react';
import { createPlatformBrowserClient, ensureAnonymousSession } from './client.js';

export interface SessionBootProps {
  supabaseUrl: string;
  supabaseAnonKey: string;
}

/**
 * Establishes an anonymous platform session once, app-wide, so identity + wallet exist
 * ahead of any credit-gated feature. Renders nothing. Failures are swallowed — the rest
 * of the app must stay fully usable without a platform session (see docs/PLATFORM.md §3).
 *
 * Mount once near the root layout:
 *   <SessionBoot supabaseUrl={...} supabaseAnonKey={...} />
 */
export function SessionBoot({ supabaseUrl, supabaseAnonKey }: SessionBootProps) {
  useEffect(() => {
    let cancelled = false;
    const supabase = createPlatformBrowserClient(supabaseUrl, supabaseAnonKey);
    (async () => {
      if (cancelled) return;
      await ensureAnonymousSession(supabase);
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [supabaseUrl, supabaseAnonKey]);

  return null;
}
