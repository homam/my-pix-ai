export class InsufficientCreditsError extends Error {
  constructor(public readonly brand: string) {
    super(`Insufficient credits for brand "${brand}"`);
    this.name = 'InsufficientCreditsError';
  }
}

export class UnknownBrandError extends Error {
  constructor(public readonly brand: string) {
    super(`Unknown brand "${brand}" — register it in core.brands first (see docs/PLATFORM.md)`);
    this.name = 'UnknownBrandError';
  }
}
